package com.vedant.cars.controller;

import com.vedant.cars.model.Car;
import com.vedant.cars.model.Booking;
import com.vedant.cars.repository.CarRepository;
import com.vedant.cars.repository.BookingRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class CarController {

    private final CarRepository carRepository;
    private final BookingRepository bookingRepository;

    public CarController(CarRepository carRepository, BookingRepository bookingRepository) {
        this.carRepository = carRepository;
        this.bookingRepository = bookingRepository;
    }

    @GetMapping("/cars")
    public List<Car> getAllCars() {
        return carRepository.findAll();
    }

    @PostMapping("/book")
    public ResponseEntity<String> bookTestDrive(@RequestBody Booking booking) {
        bookingRepository.save(booking);
        return ResponseEntity.ok("Booking confirmed for " + booking.getCustomerName() + "!");
    }
}
