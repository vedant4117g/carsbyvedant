package com.vedant.cars.model;

import jakarta.persistence.*;

@Entity
@Table(name = "cars")
public class Car {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String brand;
    private String price;
    private String hp;
    private String acceleration;
    private String imageUrl;

    public Car() {}

    public Car(String name, String brand, String price, String hp, String acceleration, String imageUrl) {
        this.name = name;
        this.brand = brand;
        this.price = price;
        this.hp = hp;
        this.acceleration = acceleration;
        this.imageUrl = imageUrl;
    }

    public Long getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getBrand() { return brand; }
    public void setBrand(String brand) { this.brand = brand; }
    public String getPrice() { return price; }
    public void setPrice(String price) { this.price = price; }
    public String getHp() { return hp; }
    public void setHp(String hp) { this.hp = hp; }
    public String getAcceleration() { return acceleration; }
    public void setAcceleration(String acceleration) { this.acceleration = acceleration; }
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
}
