package com.vedant.cars.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "bookings")
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String customerName;
    private String phone;
    private String carName;
    private LocalDateTime bookingDate;

    public Booking() {
        this.bookingDate = LocalDateTime.now();
    }

    public Booking(String customerName, String phone, String carName) {
        this.customerName = customerName;
        this.phone = phone;
        this.carName = carName;
        this.bookingDate = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getCarName() { return carName; }
    public void setCarName(String carName) { this.carName = carName; }
    public LocalDateTime getBookingDate() { return bookingDate; }
}
