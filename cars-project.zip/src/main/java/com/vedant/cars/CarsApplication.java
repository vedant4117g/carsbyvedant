package com.vedant.cars;

import com.vedant.cars.model.Car;
import com.vedant.cars.repository.CarRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class CarsApplication {

    public static void main(String[] args) {
        SpringApplication.run(CarsApplication.class, args);
    }

    @Bean
    CommandLineRunner initDatabase(CarRepository repository) {
        return args -> {
            if (repository.count() == 0) {
                repository.save(new Car("BMW M340i xDrive", "BMW", "₹ 72.90 Lakh", "382 HP", "4.4s (0-100 km/h)", "https://images.unsplash.com/photo-1555215695-3004980ad54e?auto=format&fit=crop&w=800&q=80"));
                repository.save(new Car("BMW M5 Competition", "BMW", "₹ 1.99 Crore", "617 HP", "3.3s (0-100 km/h)", "https://images.unsplash.com/photo-1617814076367-b759c7d7e738?auto=format&fit=crop&w=800&q=80"));
                repository.save(new Car("BMW M8 Competition Coupe", "BMW", "₹ 2.44 Crore", "625 HP", "3.2s (0-100 km/h)", "https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=800&q=80"));
                repository.save(new Car("Porsche 911 GT3 RS", "Porsche", "₹ 3.51 Crore", "518 HP", "3.2s (0-100 km/h)", "https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?auto=format&fit=crop&w=800&q=80"));
                System.out.println(">> Database preloaded with Luxury Cars successfully!");
            }
        };
    }
}
